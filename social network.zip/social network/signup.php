
<?php
if(isset($_POST['signup']))
{
	
$username= $_POST['username'];
echo $username;
echo"<br>";
$password= $_POST['password'];
echo $password;
echo "<br>";
$email= $_POST['email'];
echo $email;
//connection to database
//mysqli_connect(host,username,password,databasename);
$con=mysqli_connect("localhost","root","","socialnetwork");
//inser to the database
mysqli_query($con,"Insert into users(username,password,email) Values('$username','$password','$email')");
}
else
{
	header("Location:index.html");
	exit(0);
}







?>